        <div id="slider" class="nivoSlider">
                        <img src="admin/images/1.jpg" data-thumb="images/1.jpg" alt="" />
                        <img src="admin/images/2.jpg" data-thumb="images/toystory.jpg" alt="" />
                        <img src="admin/images/3.jpg" data-thumb="images/wineries.jpg" alt="" t />
                        <img src="admin/images/4.jpg"  alt="" data-transition="slideInLeft" />
                   
                    </div>
