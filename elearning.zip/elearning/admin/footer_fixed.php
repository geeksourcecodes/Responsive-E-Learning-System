<div class="navbar navbar-fixed-bottom navbar-inverse">
    <div class="navbar-inner">
        <div class="footerindex">
            <center><img width="25" height="25" src="img/chmsc.png">&nbsp;Chmsc E-Learning System Developed by BSIS-3A Design and Programmed by: John Kevin Lorayna :-P</center>

            <div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                <div class="modal-header">
                </div>
                <div class="modal-body">
                    <div class="alert alert-info">Are you Sure you Want to <strong>Logout</strong>?</div>
                </div>
                <div class="modal-footer">
                    <button class="btn" data-dismiss="modal" aria-hidden="true"><i class="icon-remove icon-large"></i>&nbsp;Close</button>
                    <a href="logout.php" class="btn btn-info"><i class="icon-signout icon-large"></i>&nbsp;Logout</a>
                </div>
            </div>
        </div>
    </div>
</div>
</div>


